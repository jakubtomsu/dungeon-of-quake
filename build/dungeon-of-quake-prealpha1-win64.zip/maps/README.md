# map directory

Maps with underscore `_` as a first character are hidden in the map selection menu.  

You can use `_quickload.dqm` map file to instantly load a level, and bypass all the menu's.  
Subdirectories are supported in the map selection menu, but their name isn't relative to this folder, it's just the last folder in path.